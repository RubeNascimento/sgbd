USE mydb;

INSERT INTO banda (nome_banda, nmembros, ano_formacao, ano_separacao, premios, website) VALUES 
('Pig Destroyer',5,1997,null,null,'pigdestroyer.band'),
('Linkin Park', 5,1996, null, "2x Grammy Award, 3x World Music Awards", "linkinpark.com" ),
('Nasum',4,1992,2005, null, null),
('I Prevail', 5, 2013, null, '1x Loudwire Music Awards', 'iprevailband.com'),
('Motionless in White', 5, 2005, null, null, 'https://www.motionlessinwhite.net/'),
('Pantera', 4, 1981, 2003, null, 'pantera.com');

INSERT INTO membro (nome_membro, data_nasc, ano_entrada, ano_saida, data_falecimento, nacionalidade, posicao) VALUES
('J.R. Hayes', "1976-10-13", 1997, null, null, "Estaduniense", "Vocalista"),
('Scott Hull', "1971-03-04", 1997, null, null, "Estaduniense", "Guitarrista"),
("Blake Harrison", "1975-12-17", 2006, null, null, "Estaduniense", "DJ"),
("Adam Jarvis", "1983-10-20", 2011, null, null, "Estaduniense", "Baterista"),
("Travis Stone", "1995-01-18", 2019, null, null, "Estaduniense", "Baixista");

